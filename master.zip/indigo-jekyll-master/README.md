# Indigo Jekyll

Based on release 2 of the UCL Design Language (https://github.com/UCL-WAMS/indigo)

This is a Jekyll Template providing templates, statics and example components for Indigo based sites.

## Instructions

1. Copy the indigo folder to your project
2. Add pages with YAML frontmatter per Jekyll instructions
3. Push to gh-pages branch
